# Hemlock template

This project is based on the [hemlock template](https://dsbowen.github.io/hemlock).

You can replicate this study with the click of a button.

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)